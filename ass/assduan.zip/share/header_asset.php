<?php  
require_once './commons/utils.php';
?>
<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="<?= $siteUrl?>css/style.css">
	<link rel="stylesheet" href="plugins/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?= $siteUrl?>plugins\simplePagination/simplePagination.css">
	<script src="plugins/bootstrap/jquery/js/jquery-3.3.1.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<link rel="stylesheet" href="css/bootstrap-3/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/main.css">
	<script src="js/jquery.min.js"></script>
	<script src="css/bootstrap-3/js/bootstrap.min.js"></script>

	<link rel="stylesheet" type="text/css" href="http://localhost:81/ass/admin/adminlte/simplePagination/jquery.simplePagination.js">





	
	